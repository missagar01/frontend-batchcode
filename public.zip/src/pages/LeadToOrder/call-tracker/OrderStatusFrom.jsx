import React from 'react'

const OrderStatusFrom = () => {
  return (
    <div>
      
    </div>
  )
}

export default OrderStatusFrom
