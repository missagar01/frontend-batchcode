"use client"

import * as React from "react"

// Stub implementation since sonner and next-themes are not installed
const Toaster = ({ ...props }: any) => {
  return null
}

export { Toaster }
