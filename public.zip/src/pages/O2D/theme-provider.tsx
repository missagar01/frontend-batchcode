'use client'

import * as React from 'react'

// Stub implementation since next-themes is not installed
export function ThemeProvider({ children, ...props }: any) {
  return <>{children}</>
}



